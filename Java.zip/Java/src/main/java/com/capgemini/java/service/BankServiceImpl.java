package com.capgemini.java.service;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

import com.capgemini.java.bean.Account;
import com.capgemini.java.bean.Transaction;
import com.capgemini.java.dao.BankDAO;
import com.capgemini.java.dao.BankDAOImpl;
import com.capgemini.java.exception.BankException;

public class BankServiceImpl implements BankService {
	BankDAO dao=new BankDAOImpl();
	Map<Integer, Account> map=new HashMap<>();
	Map<Integer, Transaction>map1=new HashMap<>();
	public boolean validateCustomerName(String Name) throws BankException{

		boolean resultFlag = false;
		String nameRegEx = "[A-Z]{1}[a-z]{4,}";

		if (!Pattern.matches(nameRegEx, Name)) {
				throw new BankException("first letter should be capital and length should be > 5");
			
		} else {
			resultFlag = true;
		}
		return resultFlag;
	}
	public boolean validateMobile(String mobile) throws BankException {

		boolean resultFlag = false;
		String mobileRegEx="^[7-9]{1}[0-9]{9}$";
		if (!Pattern.matches(mobileRegEx, mobile)) {
			throw new BankException("mobile no should start with 7,8,9 digits");
		} else {
			resultFlag = true;
		}
		return resultFlag;
}
	public boolean validateAmount(double amount) throws BankException{
		boolean resultFlag = false;
		double amountRegEx=0;
		if (amount < 500) {
					throw new BankException("account must>500");
				} else {
					resultFlag = true;
				}
				return resultFlag;
		
	}

@Override
	public int addAccountDetails(Account account) {
	double randomNumber = Math.random() * 1000000000;
	int accountId = (int) randomNumber;		
	map.put(accountId, account);
	return accountId;
	}
@Override
	public int addTransactionDetails(Transaction transaction) throws BankException {
		return dao.addTransactionDetails(transaction);
		
	}
@Override
	public Map<Integer, Account> getAllAccount() {
		// TODO Auto-generated method stub
		return null;
	}
@Override
	public Map<Integer, Transaction> getAllTransaction() {
		// TODO Auto-generated method stub
		return null;
	}
@Override
public long account() {
	long randomNumber = (long)(Math.random() * 1000000000);
	return randomNumber;
}

}
