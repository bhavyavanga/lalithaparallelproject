package com.capgemini.java.bean;

public class Transaction {
	int transactionId;
	String transactionDate;
	String accountNo;
	double amount;
	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Transaction(int transactionId, String transactionDate, String accountNo, double amount) {
		super();
		this.transactionId = transactionId;
		this.transactionDate = transactionDate;
		this.accountNo = accountNo;
		this.amount = amount;
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public String getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId + ", transactionDate=" + transactionDate + ", accountNo="
				+ accountNo + ", amount=" + amount + "]";
	}
	

}
