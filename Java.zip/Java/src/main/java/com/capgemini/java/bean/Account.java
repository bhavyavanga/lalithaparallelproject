package com.capgemini.java.bean;

public class Account {
	long accountNo;
	double balance;
	String name;
	String mobile;
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Account(long accountNo, double balance, String name, String mobile) {
		super();
		this.accountNo = accountNo;
		this.balance = balance;
		this.name = name;
		this.mobile = mobile;
	}
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", balance=" + balance + ", name=" + name + ", mobile=" + mobile
				+ "]";
	}
	

}
