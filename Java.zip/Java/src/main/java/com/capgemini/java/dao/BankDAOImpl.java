package com.capgemini.java.dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.capgemini.java.bean.Account;
import com.capgemini.java.bean.Transaction;
import com.capgemini.java.exception.BankException;

public class BankDAOImpl implements BankDAO {
	

	Map<Integer, Account> map=new HashMap<>();
	Map<Integer, Transaction>map1=new HashMap<>();

	public int addAccountDetails(Account account) {		
		double randomNumber = Math.random() * 1000000000;
		int accountId = (int) randomNumber;		
		map.put(accountId, account);
		return accountId;
	}
	public long addWithDraw(long accountNo, long withDrawAmount) {
        long drawBalance=0;
		Iterator<Account> iterator=map.values().iterator();
        while(iterator.hasNext())
        {
            Account acc=iterator.next();
       
        long accNo=acc.getAccountNo();
        double bal=acc.getBalance();
        if(accNo==accountNo)
        {
            drawBalance=(long)bal-withDrawAmount;
            acc.setBalance(drawBalance);
        }
       
    }
        return drawBalance;
    }
	public int addTransactionDetails(Transaction transaction) {
		double randomNumber = Math.random() * 1000;
		int transactionId = (int) randomNumber;
		map1.put(transactionId , transaction);
		return transactionId;
	}

	public Map<Integer, Account> getAllAccount() {
		// TODO Auto-generated method stub
		return null;
	}

	public Map<Integer, Transaction> getAllTransaction() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int balance(Account account) {
		double randomNumber = Math.random() * 1000;
		int generatedId = (int) randomNumber;		
		map.put(generatedId, account);
		return generatedId;
	}

	

}
