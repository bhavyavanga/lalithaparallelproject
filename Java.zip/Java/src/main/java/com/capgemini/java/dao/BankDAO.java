package com.capgemini.java.dao;

import java.util.Map;
import com.capgemini.java.bean.Account;
import com.capgemini.java.bean.Transaction;
import com.capgemini.java.exception.BankException;

public interface BankDAO {

	int addAccountDetails(Account account);
	 int addTransactionDetails(Transaction transaction) throws BankException;
	 int balance(Account account);
	public Map<Integer, Account> getAllAccount() throws BankException;
	public Map<Integer, Transaction> getAllTransaction() throws BankException;
}
