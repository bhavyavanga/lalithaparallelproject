package com.capgemini.java.presentation;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.capgemini.java.bean.Account;
import com.capgemini.java.bean.Transaction;
import com.capgemini.java.exception.BankException;
import com.capgemini.java.service.BankService;
import com.capgemini.java.service.BankServiceImpl;

public class MainClass {
	public static void main(String[] args) throws BankException {
		String continueChoice;
		boolean continueValue = false;
		Scanner scanner = new Scanner(System.in);
		do {
			System.out.println("*** welcome to Bank");
			System.out.println("1.Create Account");
			System.out.println("2.Deposit");
			System.out.println("3.Show Balance");
			System.out.println("4.Withdraw");
			System.out.println("5.Fund Transfer");
			System.out.println("6.Print Transaction");
			System.out.println("7.exit");
			BankService service = new BankServiceImpl();
			int choice = 0;
			boolean choiceFlag = false;
			do {
				System.out.println("Enter input:");
				try {
					choice = scanner.nextInt();
					choiceFlag = true;
					boolean custNameFlag = false;
					String firstName = "";
					String middleName = "";
					String lastName = "";
					double balance=0;
					double amount=0;
					String mobile = "";
					String Name = "";
					switch (choice) {
					
					case 1:
						
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter firstName:");
							firstName = scanner.nextLine();
							try {
								service.validateCustomerName(firstName);
								custNameFlag = true;
							} catch (BankException e) {
								custNameFlag = false;
								System.err.println(e.getMessage());
							}

						} while (!custNameFlag);

						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter middleName:");
							middleName = scanner.nextLine();

							try {
								service.validateCustomerName(middleName);
								custNameFlag = true;
							} catch (BankException e) {
								custNameFlag = false;
								System.err.println(e.getMessage());
							}

						} while (!custNameFlag);

						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter lastName:");
							lastName = scanner.nextLine();

							try {
								service.validateCustomerName(lastName);
								custNameFlag = true;
							} catch (BankException e) {
								custNameFlag = false;
								System.err.println(e.getMessage());
							}

						} while (!custNameFlag);
						
						do {
							Name = firstName.concat(middleName.concat(lastName));
							try {
								service.validateCustomerName(firstName);
								custNameFlag = true;
							} catch (BankException e) {
								custNameFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!custNameFlag);

			
						boolean mobileFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter mobileNo:");
							mobile = scanner.nextLine();
							try {
								service.validateMobile(mobile);
								mobileFlag = true;
							} catch (BankException e) {
								mobileFlag = false;
								System.err.println(e.getMessage());
							}

						} while (!mobileFlag);
					scanner = new Scanner(System.in);
							long accountId = service.account();
							System.out.println("account stored with the given id: " + accountId);
						Account account = new Account(accountId,balance,Name,mobile);
						service.account();
						break;
					
					case 2:
						boolean amountFlag=false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Account No:");
							long AccountNo = scanner.nextLong();
							System.out.println("Enter amount to deposit:");
							amount = scanner.nextDouble();
							System.out.println(amount);
							try {
								service.validateAmount(amount);
								amountFlag = true;
							} catch (BankException e) {
								amountFlag = false;
								System.err.println(e.getMessage());
							}
						}while(!amountFlag);
						try {
							int generatedId = service.addAccountDetails(account);
							System.out.println("balance: " + generatedId);
						} catch (BankException e) {
							System.err.println(e.getMessage());
						}
						Account account1 = new Account(accountId,balance,Name,mobile);
						double finalbal=balance+amount;
						System.out.println(finalbal);
						break;
					/*case 3:
						
						do {
							scanner = new Scanner(System.in);
							System.out.println("balance enquiry:");
							System.out.println("Enter accountNo:");
							accountNo = scanner.nextLine();
							try {
								service.validateAccountNo(accountNo);
								accountNOFlag = true;
							} catch (BankException e) {
								accountNOFlag = false;
								System.err.println(e.getMessage());
							}
						}while(!accountNOFlag);

						//System.out.println(balance);

						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter accountNo:");
							accountNo = scanner.nextLine();
						}*/
						
						
						
					default:
						System.out.println("input should be 1,2,3,4 or 5");
						choiceFlag = false;
						break;
					}
				} catch (InputMismatchException exception) {
					choiceFlag = false;
					System.err.println("input should contain only digits");
				}
			} while (!choiceFlag);

			do {
				scanner = new Scanner(System.in);
				System.out.println("do you want to continue again [yes/no]");
				continueChoice = scanner.nextLine();
				if (continueChoice.equalsIgnoreCase("yes")) {
					continueValue = true;
					break;
				} else if (continueChoice.equalsIgnoreCase("no")) {
					System.out.println("thank you");
					continueValue = false;
					break;
				} else {
					System.out.println("enter yes or no");
					continueValue = false;
					continue;
				}
			} while (!continueValue);
		} while (continueValue);
	}
}