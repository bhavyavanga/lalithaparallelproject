package com.capgemini.java.service;

import java.util.Map;

import com.capgemini.java.bean.Account;
import com.capgemini.java.bean.Transaction;
import com.capgemini.java.exception.BankException;

public interface BankService {

	int addAccountDetails(Account account) throws BankException;
	int addTransactionDetails(Transaction transaction) throws BankException;
	public Map<Integer, Account> getAllAccount() throws BankException;
	public Map<Integer, Transaction> getAllTransaction() throws BankException;
	public boolean validateAmount(double balance) throws BankException;
	public boolean validateCustomerName(String Name) throws BankException;
	public boolean validateMobile(String mobile) throws BankException;
	long account()throws BankException;
}
